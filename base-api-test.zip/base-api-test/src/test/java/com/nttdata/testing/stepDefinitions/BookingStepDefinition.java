package com.nttdata.testing.stepDefinitions;

import com.nttdata.testing.questions.ResponseCode;
import com.nttdata.testing.tasks.GetAllBookings;
import com.nttdata.testing.tasks.PatchBooking;
import com.nttdata.testing.tasks.PostBooking;
import com.nttdata.testing.tasks.PostToken;
import com.nttdata.testing.tasks.PutBooking;
import com.nttdata.testing.tasks.DeleteBooking;


import static net.serenitybdd.rest.SerenityRest.*;
import static net.serenitybdd.screenplay.rest.questions.ResponseConsequence.seeThatResponse;

import static net.serenitybdd.screenplay.actors.OnStage.theActorCalled;
import io.cucumber.java.en.And;
import net.serenitybdd.rest.SerenityRest;
import org.junit.Assert;

//import org.junit.Assert;


import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;
import net.serenitybdd.screenplay.rest.abilities.CallAnApi;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static net.serenitybdd.screenplay.rest.questions.ResponseConsequence.seeThatResponse;
import static org.hamcrest.Matchers.*;
import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.CoreMatchers.equalTo;

public class BookingStepDefinition {


    public static Logger LOGGER = LoggerFactory.getLogger(BookingStepDefinition.class);

    @Before
    public void setTheStage() {
        OnStage.setTheStage(new OnlineCast());
    }

    /// Obtener todos los booking
    @Given("el {actor} establece el endpoint de booking")
    public void elActorEstableceElEndpointDeBooking(Actor actor) {
        actor.whoCan(CallAnApi.at("https://restful-booker.herokuapp.com"));
    }

    @When("el {actor} realiza una solicitud GET")
    public void elActorRealizaUnaSolicitudGET(Actor actor) {
        actor.attemptsTo(GetAllBookings.fromEndpoint("/booking"));
    }

    @Then("el codigo de respuesta debe ser {int}")
    public void elCodigoDeRespuestaDebeSer(int responseCode) {
        theActorInTheSpotlight().should(seeThat("El código de respuesta", ResponseCode.getStatus(), equalTo(responseCode)));
    }

    /// Crear Booking
    @When("^el actor crea un booking con el (.*) (.*) (.*) (.*) (.*) (.*) (.*)$")
    public void elActorCreaUnBookingConEl(String firstname, String lastname, String totalprice, String depositpaid, String checkin, String checkout, String additionalneeds) {
        theActorInTheSpotlight().attemptsTo(PostBooking.fromPage(firstname, lastname, totalprice, depositpaid, checkin, checkout, additionalneeds));
    }

    /// PATCH Actualizar booking
    @When("^el actor actualiza un booking con los datos (.*) (.*) (.*)$")
    public void elActorActualizaUnBookingConLosDatos(String firstname, String lastname, String totalprice) {
        theActorInTheSpotlight().attemptsTo(PostToken.generateToken());
        theActorInTheSpotlight().attemptsTo(PatchBooking.fromPage(firstname, lastname, totalprice));
    }

    /// PUT Actualizar una reserva
    @When("el actor actualiza la reserva con los datos {string} {string} {string} {string} {string} {string} {string}")
    public void actualizarReserva(String firstname, String lastname, String totalprice, String depositpaid,
                                  String checkin, String checkout, String additionalneeds) {
        theActorInTheSpotlight().attemptsTo(PostToken.generateToken());
        theActorInTheSpotlight().attemptsTo(PutBooking.withData(firstname, lastname, totalprice, depositpaid, checkin, checkout, additionalneeds));

    }

    /// DELETE BOOKING

    @Given("que el usuario ha iniciado sesión y tiene una reserva creada")
    public void queElUsuarioHaIniciadoSesionYTieneUnaReservaCreada() {

        theActorInTheSpotlight().can(CallAnApi.at("https://restful-booker.herokuapp.com"));

        theActorInTheSpotlight().attemptsTo(
                PostToken.generateToken(), // Genera el token de autenticación
                PostBooking.fromPage(
                        "Carlos",
                        "Ramirez",
                        "100",
                        "true",
                        "2023-06-10",
                        "2023-06-15",
                        "Desayuno"
                )
        );
    }


    @When("elimina la reserva")
    public void eliminaLaReserva() {
        OnStage.theActorInTheSpotlight().attemptsTo(
                DeleteBooking.fromPage()
        );
    }

    @Then("la reserva debería eliminarse correctamente")
    public void laReservaDeberiaEliminarseCorrectamente() {
        theActorInTheSpotlight().should(
                seeThatResponse("El código de estado debe ser 201 o 204",
                        response -> response.statusCode(anyOf(is(201), is(204)))
                )
        );
    }

}






